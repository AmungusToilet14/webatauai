import { browser } from '$app/env';

export type PlaybackStart = 'cursor' | 'start';
export type AnalysisQuality = 'accurate' | 'fast';
/** 'track': one pitch curve drawn across a whole track; 'note': pitch points on single notes. */
export type PitchMode = 'track' | 'note';
/** 'freehand': drag to draw; 'points': click to place points that can be dragged. */
/** What the eraser removes: everything it touches, only notes, or only pitch. */
export type EraserMode = 'all' | 'notes' | 'pitch';
export type PitchStyle = 'freehand' | 'points';

export interface SettingsData {
	defaultLyric: string;
	gridDivision: number;
	snap: boolean;
	playbackStart: PlaybackStart;
	followPlayhead: boolean;
	/** Keep rendering while paused (off: a render that is not finished stops with playback and resumes from the cache). */
	backgroundRender: boolean;
	/** 0 = choose automatically. */
	analysisWorkers: number;
	analysisQuality: AnalysisQuality;
	backgroundAnalysis: boolean;
	showNoteNames: boolean;
	pitchMode: PitchMode;
	pitchStyle: PitchStyle;
	eraserMode: EraserMode;
	/** Ids of plugins that are switched off. */
	disabledPlugins: string[];
	/** Offer to fix lyrics the voicebank does not have after importing a project. */
	lyricDoctor: boolean;
	/** UI scale for touch targets: 'auto' picks by input device. */
	touchMode: 'auto' | 'on' | 'off';
	theme: 'auto' | 'dark' | 'light';
	/** Docked side panels of the desktop layout. */
	leftWidth: number;
	rightWidth: number;
	leftOpen: boolean;
	rightOpen: boolean;
	/** Bumped when a default changes so that stored settings can be migrated. */
	settingsVersion: number;
}

const DEFAULTS: SettingsData = {
	defaultLyric: 'a',
	gridDivision: 8,
	snap: true,
	playbackStart: 'cursor',
	followPlayhead: true,
	backgroundRender: false,
	analysisWorkers: 0,
	analysisQuality: 'fast',
	backgroundAnalysis: false,
	showNoteNames: true,
	pitchMode: 'track',
	pitchStyle: 'freehand',
	eraserMode: 'all',
	disabledPlugins: [],
	lyricDoctor: true,
	touchMode: 'auto',
	theme: 'dark',
	leftWidth: 308,
	rightWidth: 296,
	leftOpen: true,
	rightOpen: true,
	settingsVersion: 3
};

const STORAGE_KEY = 'webtau:settings';

function load(): SettingsData {
	if (!browser) return { ...DEFAULTS };
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		const stored = raw ? JSON.parse(raw) : {};
		const data: SettingsData = { ...DEFAULTS, ...stored };
		// v2: the fast DIO analyzer became the default; apply it to older stored settings once.
		if ((stored.settingsVersion ?? 1) < 2) data.analysisQuality = 'fast';
		// v3: analyzing everything in the background is opt-in (rendering caches what it needs).
		if ((stored.settingsVersion ?? 1) < 3) data.backgroundAnalysis = false;
		data.settingsVersion = DEFAULTS.settingsVersion;
		return data;
	} catch {
		return { ...DEFAULTS };
	}
}

class Settings {
	data = $state<SettingsData>(load());

	constructor() {
		if (!browser) return;
		$effect.root(() => {
			$effect(() => {
				const json = JSON.stringify($state.snapshot(this.data));
				try {
					localStorage.setItem(STORAGE_KEY, json);
				} catch {
					/* private mode: settings just won't persist */
				}
			});
		});
	}

	reset() {
		Object.assign(this.data, DEFAULTS);
	}

	/** Number of analysis workers actually used. */
	get workerCount(): number {
		if (this.data.analysisWorkers > 0) return this.data.analysisWorkers;
		const cores = browser ? navigator.hardwareConcurrency || 4 : 4;
		const mobile = browser && matchMedia('(pointer: coarse)').matches;
		return Math.max(1, Math.min(cores - 1, mobile ? 3 : 6));
	}
}

export const settings = new Settings();
