<script lang="ts">
	import Dialog from './Dialog.svelte';
	import { project } from '#lib/state/project.svelte';
	import { ui } from '#lib/state/ui.svelte';
	import type { Note } from '#lib/core/types';

	let prompt = $state('a hopeful song about finding your way after a difficult time');
	let generated = $state('');
	let report = $state('');
	let targetIds = $state<string[]>([]);
	let busy = $state(false);
	let useSelection = $state(false);

	function syllabify(word: string): string[] {
		const clean = word.toLowerCase().replace(/[^a-z']/g, '');
		if (!clean) return [];
		const parts = clean.match(/[^aeiouy]*[aeiouy]+(?:[^aeiouy](?=$))?/g) ?? [clean];
		return parts.length ? parts : [clean];
	}

	function describePattern(notes: Note[]): string {
		if (!notes.length) return 'No notes to analyze.';
		const ordered = [...notes].sort((a, b) => a.tick - b.tick);
		const intervals = ordered.slice(1).map((n, i) => Math.round(n.pitch - ordered[i].pitch));
		const contour = intervals.map((v) => (v > 0 ? '↑' : v < 0 ? '↓' : '→')).join('');
		const durations = ordered.map((n) => Math.round(n.length / 30) * 30);
		const repeated = new Map<string, number>();
		for (let i = 0; i + 2 < intervals.length; i++) {
			const key = intervals.slice(i, i + 3).join(',');
			repeated.set(key, (repeated.get(key) ?? 0) + 1);
		}
		const motif = [...repeated.entries()].sort((a, b) => b[1] - a[1])[0];
		const gaps = ordered.filter((n, i) => i > 0 && n.tick - (ordered[i - 1].tick + ordered[i - 1].length) > 120).length;
		const avg = Math.round(durations.reduce((a, b) => a + b, 0) / durations.length);
		return `${ordered.length} notes · ${gaps + 1} phrase group(s) · average note length ${avg} ticks · contour ${contour.slice(0, 48)}${contour.length > 48 ? '…' : ''}${motif && motif[1] > 1 ? ` · recurring 3-step motif (${motif[1]} appearances)` : ''}`;
	}

	function makeWords(description: string): string[] {
		const text = description.toLowerCase();
		const themes: Record<string, string[]> = {
			sad: ['empty', 'quiet', 'rain', 'fading', 'echo', 'alone', 'memory', 'blue'],
			miss: ['remember', 'distance', 'your', 'voice', 'return', 'waiting', 'still', 'here'],
			love: ['heart', 'closer', 'always', 'together', 'touch', 'forever', 'light', 'home'],
			hope: ['tomorrow', 'rising', ' sunrise', 'open', 'bright', 'begin', 'strong', 'again'],
			angry: ['breaking', 'fire', 'enough', 'stand', 'louder', 'truth', 'fight', 'free'],
			party: ['tonight', 'higher', 'move', 'dancing', 'neon', 'alive', 'wild', 'sound'],
			fear: ['shadows', 'whisper', 'darkness', 'breathing', 'hidden', 'night', 'awake', 'light'],
			default: ['under', 'open', 'wonder', 'carry', 'dream', 'moment', 'calling', 'alive']
		};
		const chosen = Object.entries(themes).filter(([key]) => key !== 'default' && text.includes(key));
		const pool = chosen.length ? chosen.flatMap(([, words]) => words) : themes.default;
		const nouns = (description.match(/[a-z]{4,}/gi) ?? []).filter((w) => !/about|with|that|this|from|when|song|slowly|realizing|ending|someone|something/.test(w.toLowerCase()));
		return [...pool, ...nouns.slice(0, 5).map((w) => w.toLowerCase()), ...pool.slice(0, 4)];
	}

	function generate() {
		const notes = project.notes.filter((n) => !useSelection || project.selection.has(n.id)).sort((a, b) => a.tick - b.tick);
		if (!notes.length) {
			ui.error(useSelection ? 'Select some notes first.' : 'There are no notes to write for yet.');
			return;
		}
		busy = true;
		targetIds = notes.map((n) => n.id);
		report = describePattern(notes);
		const words = makeWords(prompt);
		const lineBreaks = new Set<number>();
		for (let i = 1; i < notes.length; i++) {
			if (notes[i].tick - (notes[i - 1].tick + notes[i - 1].length) > 120) lineBreaks.add(i);
		}
		const syllables = words.flatMap(syllabify);
		const output: string[] = [];
		let cursor = 0;
		for (let i = 0; i < notes.length; i++) {
			if (lineBreaks.has(i)) output.push('\n');
			output.push(syllables[cursor % syllables.length]);
			cursor++;
		}
		generated = output.join(' ');
		busy = false;
	}

	function apply() {
		const tokens = generated.trim().split(/\s+/).filter(Boolean);
		if (!tokens.length || !targetIds.length) return;
		const assignments = new Map<string, string>();
		let index = 0;
		for (const token of tokens) {
			if (token === '\n') continue;
			if (index < targetIds.length) assignments.set(targetIds[index++], token);
		}
		project.edit((notes) => notes.map((n) => assignments.has(n.id) ? { ...n, lyric: assignments.get(n.id)! } : n));
		ui.toast(`Generated lyrics applied to ${assignments.size} notes.`, 'success');
		ui.closeDialog();
	}

	$effect(() => {
		if (ui.dialog === 'ai-lyrics') {
			useSelection = project.selection.size > 0;
			generated = '';
			targetIds = [];
			report = '';
		}
	});
</script>

<Dialog title="AI lyric writer" onclose={ui.closeDialog} width={620}>
	<p class="hint">Describe the song in plain English. The writer studies your note contour, rhythm, phrase gaps, and repeated motifs, then fits syllables to the notes.</p>
	<div class="field">
		<label for="ai-lyric-prompt">What should the song be about?</label>
		<textarea id="ai-lyric-prompt" rows="3" bind:value={prompt} placeholder="A nostalgic song about summer ending..." />
	</div>
	<label class="check"><input type="checkbox" bind:checked={useSelection} /> Use selected notes only {#if project.selection.size}({project.selection.size} selected){:else}(no notes selected){/if}</label>
	<div class="row actions"><button class="btn primary" disabled={!prompt.trim() || busy} onclick={generate}>{busy ? 'Analyzing…' : 'Analyze pattern & write lyrics'}</button></div>
	{#if report}
		<div class="analysis"><b>melody analysis</b><span>{report}</span></div>
		<div class="field">
			<label for="ai-lyric-result">Generated lyrics · edit before applying</label>
			<textarea id="ai-lyric-result" rows="7" bind:value={generated} spellcheck="false" />
			<span class="hint">One syllable is assigned to each note. Keep the syllables separated by spaces.</span>
		</div>
	{/if}
	{#snippet footer()}
		<button class="btn" onclick={ui.closeDialog}>Cancel</button>
		{#if report}<button class="btn primary" disabled={!generated.trim()} onclick={apply}>Apply to {targetIds.length} notes</button>{/if}
	{/snippet}
</Dialog>

<style>
	.field { display: grid; gap: 7px; margin: 12px 0; }
	.field label { font-size: 12px; font-weight: 650; color: var(--muted); }
	textarea { width: 100%; resize: vertical; }
	.check { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--muted); }
	.actions { display: flex; justify-content: flex-start; margin: 12px 0; }
	.analysis { display: grid; gap: 5px; padding: 12px; margin: 12px 0; border: 1px solid var(--border); border-radius: 10px; background: var(--surface-2); font-size: 12px; }
	.analysis b { text-transform: uppercase; letter-spacing: .08em; color: var(--accent-2); }
	.analysis span { color: var(--muted); line-height: 1.5; }
</style>
